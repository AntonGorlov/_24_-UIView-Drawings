//
//  ViewController.m
//  UIView Drawings (Lesson 24)
//
//  Created by Anton Gorlov on 08.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGDrawingView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- Orientation

- (void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    
    [self.drawingView setNeedsDisplay];
}
@end
