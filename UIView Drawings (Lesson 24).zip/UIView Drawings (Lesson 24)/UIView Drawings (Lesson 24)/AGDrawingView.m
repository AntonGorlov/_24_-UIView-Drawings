//
//  AGDrawingView.m
//  UIView Drawings (Lesson 24)
//
//  Created by Anton Gorlov on 08.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDrawingView.h"

@implementation AGDrawingView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    

    NSLog(@"drawRect %@",NSStringFromCGRect(rect));
    
    CGContextRef context =UIGraphicsGetCurrentContext();
    
/*
    
    CGContextSetFillColorWithColor(context, [UIColor grayColor].CGColor);//устанавливаем цвет
    
    CGContextFillRect(context, rect); //раскрасим
    
//создадим "Rect"
    
    CGRect square1 = CGRectMake(100, 100, 100, 100);
    CGRect square2 = CGRectMake(200, 200, 100, 100);
    CGRect square3 = CGRectMake(300, 300, 100, 100);
    
    
    CGContextAddRect(context, square1);
    CGContextAddRect(context, square2);
    CGContextAddRect(context, square3);
    
    CGContextSetFillColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextFillPath(context);
    
//создадим "круг"
    
    CGContextSetFillColorWithColor(context, [UIColor blueColor].CGColor);
    
    //рисуем заполненный цветом круг
   
    CGContextAddEllipseInRect(context, square1);
    
    CGContextFillPath(context);
    
    
    //рисуем не заполненный цветом круг
    
    CGContextSetStrokeColorWithColor(context,[UIColor blueColor].CGColor);
    
    CGContextAddEllipseInRect(context, square2);
    
    CGContextStrokePath(context);//распечатываем
    
//рисуем линии
    
    CGContextMoveToPoint(context, CGRectGetMinX(square1), CGRectGetMaxY(square1)); //контекст в этих координатах
    
    CGContextAddLineToPoint(context, CGRectGetMinX(square3), CGRectGetMaxY(square3));// до куда рисуем линию
    
    
    
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth (context,3.f);//жирность линии
    CGContextSetLineCap(context, kCGLineCapRound);
    
    CGContextStrokePath(context);
    
//рисуем кусок круга
    
    CGContextSetStrokeColorWithColor(context,[UIColor greenColor].CGColor);
    CGContextMoveToPoint(context, CGRectGetMinX(square1), CGRectGetMaxY(square1)); //арка от сюда
    
     //добавим арку
    
    CGContextAddArc(context, CGRectGetMaxX(square1), CGRectGetMaxY(square1), CGRectGetWidth(square1), M_PI, M_PI_2, YES);
    
    CGContextStrokePath(context);

//рисуем текст
    
    NSString* text = @"Text"; // создаем текст
    
    UIFont* font = [UIFont systemFontOfSize:14.f]; // создаем шрифт
    
    NSShadow* shadow =[[NSShadow alloc]init]; //создаем тень
    
    shadow.shadowOffset = CGSizeMake(1 , 1);// смещение тени (сдвиг по x , y)
    
    shadow.shadowColor = [UIColor whiteColor]; //цвет теней
    
    shadow.shadowBlurRadius = 0.5f; //размытость
    
    //теперь кладем в атрибуты
    
    NSDictionary* attributes = [NSDictionary dictionaryWithObjectsAndKeys: //атрибуты введенных параметров
                                [UIColor grayColor],   NSForegroundColorAttributeName,
                                font,                  NSFontAttributeName,
                                shadow,                NSShadowAttributeName, nil];
    
    CGSize textSize = [text sizeWithAttributes:attributes]; //  у текста ,есть собственный метод рисования
    
    CGRect textRect = CGRectMake(CGRectGetMidX(square2) - textSize.width /2,
                                 CGRectGetMidY(square2) - textSize.height /2, textSize.width, textSize.height);
    
    [text drawInRect:textRect withAttributes:attributes]; //поставлем
    
*/
    
//рисуем шахматную доску
    
    
    CGFloat offSet = 50.f; // отступ сверху и снизу
    CGFloat borderWidth = 4.f; // рамка вокруг доски
    
    CGFloat maxBoardSize = MIN(CGRectGetWidth(rect) - offSet * 2 - borderWidth * 2,
                               CGRectGetHeight(rect)- offSet * 2 - borderWidth * 2);//подсчет ширины и высоты нашей доски
    
    
    int cellSize = (int)maxBoardSize / 8; // ширина клетки (int - целое число) целое количество клеток.
    int boardSize = cellSize * 8;
    
    CGRect boardRect = CGRectMake((CGRectGetHeight(rect) - boardSize) /2,
                                  (CGRectGetHeight(rect) - boardSize) /2, boardSize, boardSize);
    
    boardRect = CGRectIntegral(boardRect); // без размытости
    
    
    for (int i = 0; i < 8; i++) { // рисуем клетки
        for (int j = 0; j < 8; j++) {
            if (i % 2 != j % 2) { // если i не четная и j не четная, то будем рисовать
                CGRect cellRect = CGRectMake(CGRectGetMinX (boardRect) + i * cellSize,
                           CGRectGetMinY (boardRect) + j * cellSize, cellSize, cellSize);
                CGContextAddRect(context, cellRect);// добвляем
                
            }
        }
    }
    
    CGContextSetFillColorWithColor(context, [UIColor grayColor].CGColor); // цвет шахматной доски
    CGContextFillPath(context);
    
    CGContextSetStrokeColorWithColor(context, [UIColor grayColor].CGColor); // граница доски
    CGContextAddRect(context, boardRect);
    
    CGContextSetLineWidth(context, borderWidth); //величина линии
    CGContextStrokePath(context);
    
    
    
}


@end
