//
//  ViewController.m
//  HomeWork Lesson 24 (UIView Drawings)
//
//  Created by Anton Gorlov on 11.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGDrawingStars.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- Orientation

- (void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    
    [self.drawingView setNeedsDisplay];
    
    self.drawingView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin
                                        |UIViewAutoresizingFlexibleTopMargin
                                        |UIViewAutoresizingFlexibleLeftMargin
                                        |UIViewAutoresizingFlexibleRightMargin;
    
    
}
@end
