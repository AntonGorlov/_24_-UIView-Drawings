//
//  AGDrawingStars.m
//  HomeWork Lesson 24 (UIView Drawings)
//
//  Created by Anton Gorlov on 11.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDrawingStars.h"

@implementation AGDrawingStars


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    NSLog(@"drawRect super stars :) %@", NSStringFromCGRect(rect));
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    
    /*
     Ученик.
     
     1. Нарисуйте пятиконечную звезду :)
     2. Добавьте окружности на концах звезды
     3. Соедините окружности линиями
    */
    CGContextSetFillColorWithColor(context, [UIColor greenColor].CGColor); //color for the view
    CGContextFillRect(context, rect);
    
    
//создадим rect
    CGRect square1 = CGRectMake(CGRectGetMinX(rect)+100, CGRectGetMinY(rect)+50,180, 180);

    CGContextAddRect(context, square1); //добавим rect
   
    
    
    
    
    CGContextSetFillColorWithColor(context, [UIColor yellowColor].CGColor);
    CGContextFillPath(context);
    
//рисуем звезду
    
    //1-part
    //перенесемся в точку Rect
    CGContextMoveToPoint(context, CGRectGetMidX(square1), CGRectGetMinY(square1));
    
    CGContextAddLineToPoint(context,CGRectGetMinX(square1)+35, CGRectGetMaxY(square1));
    
    
    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextSetLineWidth(context, 1.5f);//жироность
    
    CGContextSetLineCap(context, kCGLineCapRound); //концы линий круглые
    
    CGContextStrokePath(context);
    
    
    
    
    //2-part
    
    //перенесемся в точку Rect
    CGContextMoveToPoint(context, CGRectGetMidX(square1), CGRectGetMinY(square1));
    
    CGContextAddLineToPoint(context,CGRectGetMaxX(square1)-35, CGRectGetMaxY(square1));
    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextStrokePath(context);
    
    //3-part
    
    //перенесемся в точку Rect
    CGContextMoveToPoint(context, CGRectGetMinX(square1), CGRectGetMidY(square1));
    
    CGContextAddLineToPoint(context,CGRectGetMaxX(square1), CGRectGetMidY(square1));
    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextStrokePath(context);
    
    //4-part
    
    //перенесемся в точку Rect
    CGContextMoveToPoint(context, CGRectGetMinX(square1)+35, CGRectGetMaxY(square1));
    
    CGContextAddLineToPoint(context,CGRectGetMaxX(square1), CGRectGetMidY(square1));
    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextStrokePath(context);
    
    //5-part
    
    //перенесемся в точку Rect
    CGContextMoveToPoint(context, CGRectGetMaxX(square1)-35, CGRectGetMaxY(square1));
    
    CGContextAddLineToPoint(context,CGRectGetMinX(square1), CGRectGetMidY(square1));
    
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    CGContextStrokePath(context);
    
    /*
     Студент.
     
     4. Закрасте звезду любым цветом цветом оО
     5. При каждой перерисовке рисуйте пять таких звезд (только мелких) в рандомных точках экрана
    */
    
    //4-й пункт сделал выше.
    //5. https://github.com/AlexeyInsomnia/Lesson-24-HW-2


   
    
    /*
        Мастер
        
        6. После того как вы попрактиковались со звездами нарисуйте что-то свое, проявите творчество :)
     Нарисуем человека
    */
    
    //создадим rect
    CGRect square2 = CGRectMake(CGRectGetMinX(rect)+115, CGRectGetMinY(rect)+300,150, 200);
    
    CGContextAddRect(context, square2); //добавим rect
    
    CGContextSetFillColorWithColor(context, [UIColor  whiteColor].CGColor);
    CGContextFillPath(context);
    
    //рисуем голову
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    
    CGContextFillPath(context);

    
    CGContextAddEllipseInRect(context, CGRectMake(CGRectGetMidX(square2)-12, CGRectGetMidY(square2)-90,25, 30));
    CGContextFillPath(context);
    
    //глаза
    
    CGContextSetFillColorWithColor(context, [UIColor  whiteColor].CGColor);
    CGContextFillPath(context);
    //левый глаз
    CGContextAddEllipseInRect(context, CGRectMake(CGRectGetMidX(square2)-6, CGRectGetMidY(square2)-80,3, 3));
    CGContextFillPath(context);
    //правый глаз
    CGContextAddEllipseInRect(context, CGRectMake(CGRectGetMidX(square2)+5, CGRectGetMidY(square2)-80,3, 3));
    CGContextFillPath(context);
    
    //рисуем рот
    

    CGRect mouth = CGRectMake (CGRectGetMidX(square2)-3, CGRectGetMidY(square2)-81,8, 8);
    CGContextStrokePath(context);
    
    CGContextAddArc(context, CGRectGetMidX(mouth), CGRectGetMaxY(mouth), CGRectGetWidth(mouth), M_PI, 0, YES); // от "0" до "П"
    CGContextSetFillColorWithColor(context, [UIColor  whiteColor].CGColor);
    CGContextFillPath(context);
    
   
    
    //рисуем шею (одновременно и туловище)
    
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    
    CGContextSetLineWidth(context, 2.5f);//жироность
    
    CGContextSetLineCap(context, kCGLineCapRound); //концы линий круглые
    
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-60);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2), CGRectGetMidY(square2)-10);
    CGContextStrokePath(context);
    
    //рисуем руки
    
    //левая рука (вверх направлена)
    /*
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-60);
    CGContextStrokePath(context);
    */
    
    //изогнутая левая рука
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-40);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextStrokePath(context);
    
    //пальцы левой руки (3 пальца)
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-25, CGRectGetMidY(square2)-20);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-19);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-14, CGRectGetMidY(square2)-20);
    CGContextStrokePath(context);
    
    //пальцы правой руки (3 пальца)
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-25, CGRectGetMidY(square2)-20);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-19);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)-20, CGRectGetMidY(square2)-25);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-14, CGRectGetMidY(square2)-20);
    CGContextStrokePath(context);

    
    //правая рука (вверх направлена)
    /*
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-60);
    CGContextStrokePath(context);
    */
    //изогнутая правая рука
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-40);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-40);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-55);
    CGContextStrokePath(context);
    
    //пальцы правой руки (3 пальца)
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-55);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+25, CGRectGetMidY(square2)-62);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-55);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-62);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2)+20, CGRectGetMidY(square2)-55);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+15, CGRectGetMidY(square2)-62);
    CGContextStrokePath(context);
    
    //рисуем ноги
    
    //левая
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-12);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)-10, CGRectGetMidY(square2)+15);
    CGContextStrokePath(context);
    
    //ступни левой ноги
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextAddRect(context, CGRectMake(171, 413, 10, 5));
    CGContextFillPath(context);
    
    //ступни правой ноги
    
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextAddRect(context, CGRectMake(199, 413, 10, 5));
    CGContextFillPath(context);
    
    
    //правая
    CGContextSetFillColorWithColor(context, [UIColor  blackColor].CGColor);
    CGContextFillPath(context);
    
    CGContextMoveToPoint(context, CGRectGetMidX(square2), CGRectGetMidY(square2)-12);
    CGContextAddLineToPoint(context,CGRectGetMidX(square2)+10, CGRectGetMidY(square2)+15);
    CGContextStrokePath(context);
   

    


    
}


@end
