//
//  AGDrawingStars.h
//  HomeWork Lesson 24 (UIView Drawings)
//
//  Created by Anton Gorlov on 11.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AGDrawingStars : UIView

@end
