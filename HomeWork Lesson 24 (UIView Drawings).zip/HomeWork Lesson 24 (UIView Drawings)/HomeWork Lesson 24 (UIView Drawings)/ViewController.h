//
//  ViewController.h
//  HomeWork Lesson 24 (UIView Drawings)
//
//  Created by Anton Gorlov on 11.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>


@class AGDrawingStars;

@interface ViewController : UIViewController



@property (weak, nonatomic) IBOutlet AGDrawingStars* drawingView;

@end

